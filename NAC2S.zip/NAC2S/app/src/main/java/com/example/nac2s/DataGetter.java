package com.example.nac2s;

import android.os.AsyncTask;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;

public class DataGetter extends AsyncTask<String,Void,String> {

    private TextView txtNome;
    private TextView txtSobrenome;

    public DataGetter(TextView txtNome, TextView txtSobrenome) {
        this.txtNome = txtNome;
        this.txtSobrenome = txtSobrenome;

    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected String doInBackground(String... strings) {

        String url = strings[0];
        String result = NetworkToolkit.doGet(url);


        return result;
    }

    @Override
    protected void onPostExecute(String s) {

        try{
            JSONObject jsonResponse = new JSONObject(s);

            int dataResponse = jsonResponse.getInt("id");

            String firstName = jsonResponse.getString("title");
            String lastName = jsonResponse.getString("completed");

            txtNome.setText(firstName);
            txtSobrenome.setText(lastName);

        }
        catch(JSONException e){
            this.txtNome.setText(e.toString());
        }
    }
}

