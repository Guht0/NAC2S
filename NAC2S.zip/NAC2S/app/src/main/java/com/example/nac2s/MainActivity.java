package com.example.nac2s;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void executaConsulta(View view){

        String url = "https://jsonplaceholder.typicode.com/todos/";

        EditText txtConsulta = findViewById(R.id.textid);
        url += txtConsulta.getText().toString();

        TextView txtNome = findViewById(R.id.textitle);
        TextView txtSobrenome = findViewById(R.id.textcompleted);

        new DataGetter(txtNome,txtSobrenome).execute(url);

    }

}
